var voteSubmit = document.getElementById("voteSubmit");
voteSubmit.addEventListener("click",function() {
  var url = "/polls" + {{certainPoll.data.id}} + "/vote/" + document.querySelector('[name="option"]:checked').value;
  document.getElementById("voteForm").action = url;
  console.log(url);
});
