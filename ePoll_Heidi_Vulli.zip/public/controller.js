var ePoll = angular.module('ePoll',['ui.router']);

ePoll.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider
  // route to show all polls
  .state('polls', {
    url: '/polls',
    templateUrl: 'views/polls.html',
    controller: 'pollsController'
  })
  // route to create new poll
  .state('new', {
    url: '/polls/add',
    templateUrl: 'views/newPoll.html',
    controller: 'newController'
  })

  // route to show a poll with :id
  .state('id', {
    url: '/polls/:id',
    templateUrl: 'views/certainPoll.html',
    controller: 'idController'
  });
  $urlRouterProvider.otherwise('/polls');
});
// Controls the "main page" /polls
ePoll.controller('pollsController', function($scope,$http) {
  $http.get('/polls').then(function(data) {
    $scope.result = data;
  });
});
// Controls the page where you can make new polls
ePoll.controller('newController',function($scope,$http) {
  $http.get('/polls/add').then(function(data) {
    $scope.result = data;
  });
});
// Controls pages where you can vote on a certain poll
ePoll.controller('idController', function($scope,$http,$location) {
  var pagePath = $location.path();
  $http.get(pagePath).then(function(data) {
    $scope.certainPoll = data;
  });
});
// Controls voting of polls
ePoll.controller('voteFormController', function($scope,$http,$location) {
  $scope.option = {val:0};
  $scope.showBeforeSubmit = true;
  $scope.showAfterSubmit = false;
  $scope.showErrorCase = false;
  $scope.submit = function() {
    if ($scope.option.val != 0) {
      var url = $location.path() + "/vote/"+ $scope.option.val;
      $http.post(url).then(function() {
        var pagePath = $location.path();
        // Let's refresh the page
        $http.get(pagePath).then(function(data) {
          $scope.certainPoll = data;
        });
        $scope.showBeforeSubmit = false;
        $scope.showAfterSubmit = true;
        $scope.showErrorCase = false;
      });
    } else {
      // If the user hasn't voted anything
      $scope.showErrorCase = true;
    }
  }
});
// Controls pages where you can vote on a certain poll
ePoll.controller('newFormController', function($scope,$http,$location) {
  $scope.options = {val:""};
  $scope.title = {val:""};
  $scope.showBeforeSubmit = true;
  $scope.showErrorCase = false;
  $scope.showAfterSubmit = false;

  $scope.submit = function () {
    // Checking that the fields are not empty
    if ($scope.options.val != "" && $scope.title.val) {
      // Splitting options into array by ;-character
      var options = $scope.options.val.split(";");
      var body = {"title": $scope.title.val,"options":options};
      var url = $location.path();
      $http.post(url,body).then(function() {
        $scope.showBeforeSubmit = false;
        $scope.showAfterSubmit = true;
      });
    //
    } else {
      $scope.showErrorCase = true;
    }
  };
});
